Group 13 | Project 4 | submission_improved

This is the earlier ensemble of graph label propagation and support-vector classifiers. selection.json contains its six components and weights. model_scores.npz is its frozen output on the fixed competition test recordings.

Extract the archive and run python predict.py for exact replay. To refit, install requirements.txt using Python 3.11, then run python predict.py --data "/path/to/project4". The data folder must contain the original train.csv, test.csv and audio directory.
