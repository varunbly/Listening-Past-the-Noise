from pathlib import Path
import argparse
import csv
import json
import numpy as np

BASE = Path(__file__).resolve().parent

def refit(data, jobs):
    from improve import prepare, fisher_features
    from deliver import predict_one, temper
    train, test, x, caches = prepare(data, jobs)
    checked = train.checked.eq(1).to_numpy()
    for size in (8, 32, 64):
        fisher_features(caches, checked, len(train), size, jobs)
    classes, y = np.unique(train.label.to_numpy(str), return_inverse=True)
    query = np.arange(len(train), len(train) + len(test))
    config = json.loads((BASE / "selection.json").read_text())
    scores = np.zeros((len(test),len(classes)))
    graphs = {}
    for model in config["models"]:
        p = predict_one(model["config"], x, train, y, np.flatnonzero(checked), query, caches, graphs)
        scores += model["weight"] * temper(p, config["probability_power"])
    return test.id.to_numpy(str), classes, scores

def main():
    parser = argparse.ArgumentParser(description="Reproduce the earlier six-component Project 4 ensemble.")
    parser.add_argument("--data", type=Path, help="Refit from the original extracted competition data")
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--output", type=Path, default=Path("submission_improved.csv"))
    args = parser.parse_args()
    if args.data:
        ids, classes, scores = refit(args.data, args.jobs)
    else:
        with np.load(BASE / "model_scores.npz") as saved:
            ids, classes, scores = saved["ids"], saved["classes"], saved["probabilities"]
    if scores.shape != (1592,41) or len(set(ids)) != 1592 or not np.isfinite(scores).all():
        raise ValueError("Unexpected model output")
    top = classes[np.argsort(-scores,axis=1)[:,:3]]
    with args.output.open("w",newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["id","label"])
        writer.writerows((ident," ".join(row)) for ident,row in zip(ids,top))

if __name__ == "__main__":
    main()
